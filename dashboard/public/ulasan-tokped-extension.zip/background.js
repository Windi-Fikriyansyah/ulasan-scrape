// Service worker: mengatur pekerjaan ulasan marketplace, lead maps, dan autopost grup Facebook.

const DASHBOARDS = [
  "http://localhost:3000",
  "http://127.0.0.1:3000",
  "http://localhost:3001",
];

let job = null; // { jobId, dashTabId, scrapeTabId, market, type, ... }

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const clamp = (v, min, max, fallback) => {
  const n = Number(v);
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback;
};

async function getJob() {
  if (job) return job;
  try {
    const s = await chrome.storage.session.get("job");
    job = s.job || null;
  } catch (_) {
    job = null;
  }
  return job;
}

async function setJob(j) {
  job = j;
  try {
    if (j) await chrome.storage.session.set({ job: j });
    else await chrome.storage.session.remove("job");
  } catch (_) {}
}

function emit(tabId, event) {
  if (tabId == null) return;
  chrome.tabs.sendMessage(tabId, { kind: "tkp-event", event }).catch(() => {});
}

function waitForLoad(tabId, timeout = 45000) {
  return new Promise((resolve) => {
    let finished = false;
    let timer;
    const listener = (id, info) => {
      if (id === tabId && info.status === "complete") finish(true);
    };
    function finish(v) {
      if (finished) return;
      finished = true;
      chrome.tabs.onUpdated.removeListener(listener);
      clearTimeout(timer);
      resolve(v);
    }
    timer = setTimeout(() => finish(false), timeout);
    chrome.tabs.onUpdated.addListener(listener);
    chrome.tabs.get(tabId).then((t) => { if (t.status === "complete") finish(true); }).catch(() => finish(false));
  });
}

async function endJob(j) {
  await setJob(null);
  if (j && j.scrapeTabId) {
    chrome.tabs.remove(j.scrapeTabId).catch(() => {});
  }
}

async function failJob(message) {
  const j = await getJob();
  if (!j) return;
  emit(j.dashTabId, { type: "ERROR", jobId: j.jobId, message });
  await endJob(j);
}

// -----------------------------------------------------------------------------
// PENGAMBILAN ULASAN & LEAD MAPS
// -----------------------------------------------------------------------------

async function startJob(cmd, dashTabId) {
  if (await getJob()) {
    emit(dashTabId, {
      type: "ERROR",
      jobId: cmd.jobId,
      message: "Masih ada proses yang berjalan. Tunggu selesai atau hentikan dulu.",
    });
    return;
  }

  const market = cmd.market || "tokopedia";
  let url;
  try {
    const u = new URL(cmd.url);
    if (u.protocol !== "https:") throw new Error("bad");
    if (market === "tokopedia") {
      if (u.hostname !== "www.tokopedia.com") throw new Error("bad");
    } else if (market === "shopee") {
      if (u.hostname !== "shopee.co.id") throw new Error("bad");
    } else if (market === "gmaps") {
      if (u.hostname !== "www.google.com" || !u.pathname.startsWith("/maps")) throw new Error("bad");
    } else {
      throw new Error("bad");
    }
    url = u.href;
  } catch (_) {
    const label = market === "shopee" ? "Shopee" : market === "gmaps" ? "Google Maps" : "Tokopedia";
    emit(dashTabId, { type: "ERROR", jobId: cmd.jobId, message: `Link itu bukan halaman ${label}.` });
    return;
  }

  const tab = await chrome.tabs.create({ url, active: false });
  await setJob({ jobId: cmd.jobId, dashTabId, scrapeTabId: tab.id, market, type: "scrape" });

  const label = market === "shopee" ? "Shopee" : market === "gmaps" ? "Google Maps" : "Tokopedia";
  const loaded = await waitForLoad(tab.id);
  if (!loaded) return failJob(`Halaman ${label} tidak selesai dimuat dalam 45 detik.`);

  const options = {
    ...(cmd.options || {}),
    maxPages: clamp(cmd.options && cmd.options.maxPages, 1, 200, 10),
    delay: clamp(cmd.options && cmd.options.delay, 500, 10000, 1200),
  };

  for (let i = 0; i < 20; i++) {
    try {
      const r = await chrome.tabs.sendMessage(tab.id, { kind: "tkp-start", options });
      if (r && r.ok) return;
    } catch (_) {}
    await sleep(500);
  }
  await failJob(`Extension tidak bisa masuk ke halaman ${label}. Muat ulang extension, lalu coba lagi.`);
}

async function stopJob() {
  const j = await getJob();
  if (!j) return;
  if (j.type === "autopost") {
    await stopAutopostRun();
    return;
  }
  if (j.type === "fb-groups") {
    await stopFbGroups();
    return;
  }
  if (j.scrapeTabId) {
    chrome.tabs.sendMessage(j.scrapeTabId, { kind: "tkp-stop" }).catch(() => {});
  }
}

// -----------------------------------------------------------------------------
// AUTOPOST: AMBIL DAFTAR GRUP FACEBOOK
// -----------------------------------------------------------------------------

let fbGroupsWatchdog = null;

async function startFbGroups(dashTabId) {
  if (await getJob()) {
    emit(dashTabId, {
      type: "ERROR",
      message: "Masih ada proses lain yang berjalan. Tunggu selesai atau hentikan dulu.",
    });
    return;
  }

  const url = "https://www.facebook.com/groups/joins/";
  // Buka tab aktif (visible) agar rendering DOM dan IntersectionObserver Facebook berjalan optimal
  const tab = await chrome.tabs.create({ url, active: true });
  await setJob({ dashTabId, scrapeTabId: tab.id, type: "fb-groups", startedAt: Date.now() });

  // Batas waktu pengaman 10 menit di background
  if (fbGroupsWatchdog) clearTimeout(fbGroupsWatchdog);
  fbGroupsWatchdog = setTimeout(async () => {
    const cur = await getJob();
    if (cur && cur.type === "fb-groups") {
      emit(cur.dashTabId, {
        type: "ERROR",
        message: "Pengambilan grup Facebook melebihi batas waktu maksimal (10 menit).",
      });
      if (cur.dashTabId) {
        chrome.tabs.update(cur.dashTabId, { active: true }).catch(() => {});
      }
      await endJob(cur);
    }
  }, 10 * 60 * 1000);

  const loaded = await waitForLoad(tab.id);
  if (!loaded) {
    if (fbGroupsWatchdog) clearTimeout(fbGroupsWatchdog);
    emit(dashTabId, { type: "ERROR", message: "Halaman grup Facebook tidak selesai dimuat." });
    if (dashTabId) chrome.tabs.update(dashTabId, { active: true }).catch(() => {});
    await endJob({ scrapeTabId: tab.id });
    return;
  }

  // Coba inisiasi pengumpulan grup
  for (let i = 0; i < 15; i++) {
    try {
      const r = await chrome.tabs.sendMessage(tab.id, { kind: "fb-groups-start" });
      if (r && r.ok) return;
    } catch (_) {}
    await sleep(600);
  }

  if (fbGroupsWatchdog) clearTimeout(fbGroupsWatchdog);
  emit(dashTabId, { type: "ERROR", message: "Extension tidak dapat berkomunikasi dengan halaman Facebook." });
  if (dashTabId) chrome.tabs.update(dashTabId, { active: true }).catch(() => {});
  await endJob({ scrapeTabId: tab.id });
}

async function stopFbGroups() {
  if (fbGroupsWatchdog) {
    clearTimeout(fbGroupsWatchdog);
    fbGroupsWatchdog = null;
  }
  const j = await getJob();
  if (!j || j.type !== "fb-groups") return;
  if (j.scrapeTabId) {
    chrome.tabs.sendMessage(j.scrapeTabId, { kind: "fb-groups-stop" }).catch(() => {});
  }
  await sleep(300);
  if (j.dashTabId) {
    chrome.tabs.update(j.dashTabId, { active: true }).catch(() => {});
  }
  await endJob(j);
}

// -----------------------------------------------------------------------------
// AUTOPOST: PENGIRIMAN POSTINGAN OTOMATIS
// -----------------------------------------------------------------------------

let autopostState = {
  active: false,
  paused: false,
  stopped: false,
  run: null,
  templates: [],
  targetIndex: 0,
  dashTabId: null,
  activeTabId: null,
};

async function startAutopostRun(cmd, dashTabId) {
  if (await getJob()) {
    emit(dashTabId, {
      type: "ERROR",
      message: "Masih ada proses lain yang berjalan. Tunggu selesai atau hentikan dulu.",
    });
    return;
  }

  const run = cmd.run;
  if (!run || !run.targets || run.targets.length === 0) {
    emit(dashTabId, { type: "ERROR", message: "Daftar target postingan kosong." });
    return;
  }

  await setJob({ jobId: run.id, dashTabId, type: "autopost" });

  autopostState = {
    active: true,
    paused: false,
    stopped: false,
    run,
    templates: cmd.templates || [],
    targetIndex: 0,
    dashTabId,
    activeTabId: null,
  };

  emit(dashTabId, { type: "FB_STATUS", runId: run.id, state: "running" });

  // Jalankan loop pengiriman secara asinkron di latar belakang
  runAutopostLoop().catch((err) => {
    console.error("Autopost loop error:", err);
  });
}

async function pauseAutopostRun() {
  if (!autopostState.active) return;
  autopostState.paused = true;
  emit(autopostState.dashTabId, {
    type: "FB_STATUS",
    runId: autopostState.run.id,
    state: "paused",
  });
}

async function resumeAutopostRun() {
  if (!autopostState.active) return;
  autopostState.paused = false;
  emit(autopostState.dashTabId, {
    type: "FB_STATUS",
    runId: autopostState.run.id,
    state: "running",
  });
}

async function stopAutopostRun() {
  if (!autopostState.active) return;
  autopostState.stopped = true;
  autopostState.active = false;
  if (autopostState.activeTabId) {
    chrome.tabs.remove(autopostState.activeTabId).catch(() => {});
  }
  emit(autopostState.dashTabId, {
    type: "FB_STATUS",
    runId: autopostState.run.id,
    state: "stopped",
  });
  await setJob(null);
}

async function runAutopostLoop() {
  const state = autopostState;
  const run = state.run;
  const targets = run.targets;
  const settings = run.settings || {};
  const delayMin = Math.max(30, Number(settings.delayMin) || 60);
  const delayMax = Math.max(delayMin, Number(settings.delayMax) || 150);

  for (let i = 0; i < targets.length; i++) {
    if (state.stopped) break;

    // Tunggu jika dalam status jeda (paused)
    while (state.paused && !state.stopped) {
      await sleep(1000);
    }
    if (state.stopped) break;

    state.targetIndex = i;
    const target = targets[i];

    // Beritahu dashboard bahwa target ini sedang diproses
    emit(state.dashTabId, {
      type: "FB_TARGET",
      runId: run.id,
      target: { ...target, status: "posting" },
    });

    // Temukan template yang cocok
    const template = state.templates.find((t) => t.id === target.templateId) || state.templates[0] || {
      body: "",
      images: [],
    };

    // Buka tab grup di latar belakang
    let targetTab = null;
    let postResult = null;

    try {
      targetTab = await chrome.tabs.create({ url: target.groupUrl, active: false });
      state.activeTabId = targetTab.id;

      const loaded = await waitForLoad(targetTab.id, 40000);
      if (!loaded) {
        postResult = {
          status: "failed",
          message: "Halaman grup tidak selesai dimuat dalam 40 detik.",
        };
      } else {
        // Tunggu content script merespons
        let started = false;
        for (let attempt = 0; attempt < 15; attempt++) {
          if (state.stopped) break;
          try {
            const r = await chrome.tabs.sendMessage(targetTab.id, {
              kind: "fb-post-start",
              target,
              template,
              dry: run.dry,
            });
            if (r && r.ok) {
              started = true;
              break;
            }
          } catch (_) {}
          await sleep(700);
        }

        if (!started && !state.stopped) {
          postResult = {
            status: "failed",
            message: "Extension tidak dapat terhubung ke halaman grup Facebook.",
          };
        } else {
          // Tunggu hasil dari konten script via tkp-scrape fb-target-done
          const waitResult = await new Promise((resolve) => {
            const timeout = setTimeout(() => {
              chrome.runtime.onMessage.removeListener(listener);
              resolve({ status: "failed", message: "Waktu tunggu proses posting grup habis (timeout 90s)." });
            }, 90000);

            const listener = (msg) => {
              if (msg && msg.kind === "tkp-scrape" && msg.type === "fb-target-done") {
                clearTimeout(timeout);
                chrome.runtime.onMessage.removeListener(listener);
                resolve(msg);
              }
            };
            chrome.runtime.onMessage.addListener(listener);
          });
          postResult = waitResult;
        }
      }
    } catch (tabErr) {
      postResult = {
        status: "failed",
        message: tabErr.message || "Gagal membuka tab grup Facebook.",
      };
    } finally {
      if (targetTab) {
        chrome.tabs.remove(targetTab.id).catch(() => {});
        state.activeTabId = null;
      }
    }

    if (state.stopped) break;

    // Perbarui status target di dashboard
    const finalTarget = {
      ...target,
      status: postResult.status || "failed",
      message: postResult.message || "",
      at: Date.now(),
    };
    emit(state.dashTabId, {
      type: "FB_TARGET",
      runId: run.id,
      target: finalTarget,
    });

    // Jika terdeteksi checkpoint atau pembatasan akun, HENTIKAN SEMUA
    if (postResult.checkpoint) {
      state.stopped = true;
      state.active = false;
      emit(state.dashTabId, {
        type: "ERROR",
        message: "Akun Facebook terkena pembatasan atau verifikasi (checkpoint). Pengiriman otomatis dihentikan demi keamanan akun.",
      });
      emit(state.dashTabId, {
        type: "FB_STATUS",
        runId: run.id,
        state: "error",
      });
      await setJob(null);
      return;
    }

    // Jika masih ada target berikutnya dan belum selesai/dihentikan
    if (i < targets.length - 1 && !state.stopped) {
      // Hitung jeda acak
      const delaySec = Math.floor(Math.random() * (delayMax - delayMin + 1)) + delayMin;
      const nextTarget = targets[i + 1];

      for (let s = delaySec; s > 0; s--) {
        if (state.stopped) break;
        while (state.paused && !state.stopped) {
          await sleep(1000);
        }
        if (state.stopped) break;

        emit(state.dashTabId, {
          type: "FB_STATUS",
          runId: run.id,
          state: "running",
          nextInSec: s,
          currentTargetId: nextTarget.id,
        });
        await sleep(1000);
      }
    }
  }

  if (!state.stopped) {
    state.active = false;
    emit(state.dashTabId, {
      type: "FB_STATUS",
      runId: run.id,
      state: "done",
    });
    await setJob(null);
  }
}

// -----------------------------------------------------------------------------
// EVENT HANDLERS & LISTENERS
// -----------------------------------------------------------------------------

async function handleScrape(msg, senderTabId) {
  const j = await getJob();
  if (!j) return;

  switch (msg.type) {
    case "meta":
      if (senderTabId === j.scrapeTabId) {
        emit(j.dashTabId, { type: "META", jobId: j.jobId, title: msg.title, image: msg.image, sample: msg.sample });
      }
      break;
    case "batch":
      if (senderTabId === j.scrapeTabId) {
        emit(j.dashTabId, { type: "BATCH", jobId: j.jobId, page: msg.page, reviews: msg.reviews });
      }
      break;
    case "leads":
      if (senderTabId === j.scrapeTabId) {
        emit(j.dashTabId, { type: "LEADS", jobId: j.jobId, found: msg.found, leads: msg.leads });
      }
      break;
    case "done":
      if (senderTabId === j.scrapeTabId) {
        emit(j.dashTabId, { type: "DONE", jobId: j.jobId, stopped: !!msg.stopped });
        await endJob(j);
      }
      break;
    case "error":
      if (senderTabId === j.scrapeTabId) {
        emit(j.dashTabId, { type: "ERROR", jobId: j.jobId, message: msg.message });
        await endJob(j);
      }
      break;
    case "fb-groups":
      emit(j.dashTabId, { type: "FB_GROUPS", found: msg.found, groups: msg.groups });
      break;
    case "fb-groups-done":
      if (fbGroupsWatchdog) {
        clearTimeout(fbGroupsWatchdog);
        fbGroupsWatchdog = null;
      }
      emit(j.dashTabId, {
        type: "FB_GROUPS_DONE",
        stopped: !!msg.stopped,
        total: msg.total,
        diag: msg.diag,
      });
      if (j.dashTabId) {
        chrome.tabs.update(j.dashTabId, { active: true }).catch(() => {});
      }
      await endJob(j);
      break;
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return;

  if (msg.kind === "tkp-sleep") {
    setTimeout(() => sendResponse({ ok: true }), clamp(msg.ms, 0, 20000, 500));
    return true;
  }

  (async () => {
    if (msg.kind === "tkp-cmd") {
      const cmd = msg.cmd || {};
      const dashTabId = sender.tab && sender.tab.id;
      if (cmd.type === "START") await startJob(cmd, dashTabId);
      else if (cmd.type === "STOP") await stopJob();
      else if (cmd.type === "FB_FETCH_GROUPS") await startFbGroups(dashTabId);
      else if (cmd.type === "FB_STOP_FETCH_GROUPS") await stopFbGroups();
      else if (cmd.type === "FB_RUN_START") await startAutopostRun(cmd, dashTabId);
      else if (cmd.type === "FB_RUN_PAUSE") await pauseAutopostRun();
      else if (cmd.type === "FB_RUN_RESUME") await resumeAutopostRun();
      else if (cmd.type === "FB_RUN_STOP") await stopAutopostRun();
    } else if (msg.kind === "tkp-scrape") {
      await handleScrape(msg, sender.tab && sender.tab.id);
    }
    sendResponse({ ok: true });
  })();
  return true;
});

chrome.tabs.onRemoved.addListener(async (tabId) => {
  const j = await getJob();
  if (j && tabId === j.scrapeTabId) {
    if (j.type === "fb-groups") {
      if (fbGroupsWatchdog) {
        clearTimeout(fbGroupsWatchdog);
        fbGroupsWatchdog = null;
      }
      emit(j.dashTabId, {
        type: "FB_GROUPS_DONE",
        stopped: true,
        total: 0,
        diag: { stopReason: "tab_ditutup_pengguna" },
      });
      if (j.dashTabId) {
        chrome.tabs.update(j.dashTabId, { active: true }).catch(() => {});
      }
      await setJob(null);
    } else {
      const label = j.market === "shopee" ? "Shopee" : j.market === "gmaps" ? "Google Maps" : "Tokopedia";
      emit(j.dashTabId, {
        type: "ERROR",
        jobId: j.jobId,
        message: `Tab ${label} ditutup sebelum pengambilan selesai.`,
      });
      await setJob(null);
    }
  }
});

chrome.action.onClicked.addListener(async () => {
  const tabs = await chrome.tabs.query({});
  const found = tabs.find((t) => t.url && DASHBOARDS.some((d) => t.url.startsWith(d)));
  if (found) {
    await chrome.tabs.update(found.id, { active: true });
    await chrome.windows.update(found.windowId, { focused: true });
  } else {
    chrome.tabs.create({ url: DASHBOARDS[0] });
  }
});
