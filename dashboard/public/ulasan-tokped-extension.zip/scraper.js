// Dijalankan di halaman Tokopedia. Hanya bekerja bila diperintah oleh background.js.
(() => {
  if (window.__tkpScraper) return;
  window.__tkpScraper = true;

  let running = false;
  let stopRequested = false;

  // Jeda lewat service worker supaya tidak terkena throttle timer tab latar belakang.
  const sleep = async (ms) => {
    try { await chrome.runtime.sendMessage({ kind: "tkp-sleep", ms }); }
    catch (_) { await new Promise((r) => setTimeout(r, ms)); }
  };

  const send = (payload) => {
    try { chrome.runtime.sendMessage({ kind: "tkp-scrape", ...payload }); } catch (_) {}
  };

  const REL_DATE = /(hari ini|kemarin|\d+\s*(hari|minggu|bulan|tahun)\s*lalu|sebulan lalu|seminggu lalu|setahun lalu|\d{1,2}\s+\w+\s+\d{4})/i;

  function findReviewCards() {
    const cards = new Set();
    document.querySelectorAll('[data-testid="lblItemUlasan"]').forEach((t) => {
      const card = t.closest("article") || (t.parentElement && t.parentElement.parentElement && t.parentElement.parentElement.parentElement);
      if (card) cards.add(card);
    });
    if (cards.size) return [...cards];
    return [...document.querySelectorAll("article")].filter((a) =>
      a.querySelector('[data-testid="icnStarRating"], [aria-label*="bintang" i]')
    );
  }

  // ---------------------------------------------------------------
  // RATING BINTANG
  // Dicoba berlapis, karena Tokopedia sering mengubah markup-nya:
  // 1) aria-label/title/alt seperti "bintang 5" atau "5 bintang"
  // 2) itemprop="ratingValue"
  // 3) menghitung ikon bintang yang terisi
  // ---------------------------------------------------------------
  const RATING_RE = /(?:bintang|star|rating)\D{0,3}([1-5])(?!\d)|(?<!\d)([1-5])\D{0,3}(?:bintang|star)/i;

  function ratingFromAttrs(el) {
    for (const a of ["aria-label", "title", "alt"]) {
      const v = el.getAttribute && el.getAttribute(a);
      if (!v) continue;
      const m = v.match(RATING_RE);
      if (m) return Number(m[1] || m[2]);
    }
    return 0;
  }

  function isFilledStar(el) {
    if (el.tagName === "IMG") {
      const s = (el.currentSrc || el.src || "").toLowerCase();
      return !/empty|outline|inactive|grey|gray|blank|disable|unfill/.test(s);
    }
    const cls = (el.getAttribute("class") || "").toLowerCase();
    if (/empty|inactive|disable/.test(cls)) return false;
    const shape = el.querySelector("path, polygon, circle") || el;
    const m = getComputedStyle(shape).fill.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
    if (!m) return true;
    const [r, g, b] = [Number(m[1]), Number(m[2]), Number(m[3])];
    const grey = Math.max(r, g, b) - Math.min(r, g, b) <= 40 && (r + g + b) / 3 > 150;
    return !grey; // hanya abu muda yang dianggap bintang kosong
  }

  function countStars(card) {
    const box = card.querySelector('[data-testid="icnStarRating"]');
    let stars;
    if (box) stars = [...box.querySelectorAll("img, svg")];
    else stars = [...card.querySelectorAll("img")].filter((i) => /star|bintang/i.test((i.currentSrc || i.src || "") + (i.alt || "")));
    const filled = stars.filter(isFilledStar).length;
    return filled >= 1 && filled <= 5 ? filled : 0;
  }

  function parseRating(card) {
    const box = card.querySelector('[data-testid="icnStarRating"]');
    if (box) {
      let r = ratingFromAttrs(box);
      if (r) return r;
      for (const el of box.querySelectorAll("[aria-label], [title], img[alt]")) {
        r = ratingFromAttrs(el);
        if (r) return r;
      }
    }
    for (const el of card.querySelectorAll("[aria-label], [title], img[alt]")) {
      const r = ratingFromAttrs(el);
      if (r) return r;
    }
    const ip = card.querySelector('[itemprop="ratingValue"]');
    if (ip) {
      const v = Number(ip.getAttribute("content") || ip.textContent);
      if (v >= 1 && v <= 5) return Math.round(v);
    }
    return countStars(card);
  }

  // ---------------------------------------------------------------
  // GAMBAR: pisahkan foto profil (avatar) dari foto ulasan
  // Avatar = gambar pemakai yang ada di bagian kepala kartu (sebelum teks
  // ulasan) dan berukuran kecil, atau URL-nya berpola avatar.
  // Foto ulasan = gambar setelah teks ulasan. Gambar di dalam balasan
  // penjual diabaikan.
  // ---------------------------------------------------------------
  const AVATAR_URL = /\/user-\d+\/|default_picture_user|default[_-]toped|avatar|profile/i;
  const NOT_PHOTO = /\.svg(\?|$)|emoji|badge|icon|medal|star/i;

  const imgUrl = (img) => {
    const s = img.currentSrc || img.src || img.getAttribute("data-src") || "";
    return s.startsWith("data:") ? "" : s;
  };

  function classifyImages(card, textEl, replyEl) {
    let avatar = "";
    const photos = [];
    let firstSeen = false;

    for (const img of card.querySelectorAll("img")) {
      if (replyEl && replyEl.contains(img)) continue;
      const src = imgUrl(img);
      if (!src || !/tokopedia/i.test(src) || NOT_PHOTO.test(src)) continue;

      const rect = img.getBoundingClientRect();
      const w = rect.width || Number(img.getAttribute("width")) || 0;
      const h = rect.height || Number(img.getAttribute("height")) || 0;
      const small = w > 0 && w <= 64 && h <= 64;
      const beforeText = textEl ? !!(textEl.compareDocumentPosition(img) & Node.DOCUMENT_POSITION_PRECEDING) : !firstSeen;
      firstSeen = true;

      const isAvatar = AVATAR_URL.test(src) || (beforeText && small);
      if (isAvatar) {
        if (!avatar) avatar = src; // avatar kedua dibuang, bukan dijadikan foto
      } else {
        photos.push(src);
      }
    }
    return { avatar, images: [...new Set(photos)] };
  }

  function parseCard(card) {
    const textEl = card.querySelector('[data-testid="lblItemUlasan"]');
    const review = ((textEl && textEl.innerText) || "").trim();

    const nameEl = card.querySelector('[data-testid="lblUserName"], span.name, .name');
    const name = ((nameEl && nameEl.innerText) || "").trim();

    let date = "";
    for (const el of card.querySelectorAll("p, span, time")) {
      const t = (el.innerText || "").trim();
      if (t && t.length < 30 && REL_DATE.test(t)) { date = t; break; }
    }

    let variant = "";
    for (const el of card.querySelectorAll("p, span")) {
      const t = (el.innerText || "").trim();
      if (/^varian\s*:/i.test(t)) { variant = t.replace(/^varian\s*:\s*/i, ""); break; }
    }

    const replyEl = card.querySelector('[data-testid="lblSellerReply"], [data-testid*="reply" i]');
    const { avatar, images } = classifyImages(card, textEl, replyEl);

    return {
      name,
      avatar,
      rating: parseRating(card),
      date,
      variant,
      review,
      images,
      seller_reply: ((replyEl && replyEl.innerText) || "").trim(),
    };
  }

  // HTML ringkas satu kartu ulasan, untuk diagnosa bila rating/foto salah baca.
  function sampleHtml(card) {
    try {
      const c = card.cloneNode(true);
      c.querySelectorAll("script, style").forEach((n) => n.remove());
      c.querySelectorAll("path").forEach((p) => p.removeAttribute("d"));
      c.querySelectorAll("*").forEach((n) => {
        n.removeAttribute("class");
        n.removeAttribute("style");
        n.removeAttribute("srcset");
        for (const a of ["src", "data-src"]) {
          const v = n.getAttribute(a);
          if (v && v.length > 140) n.setAttribute(a, v.slice(0, 140) + "…");
        }
      });
      return c.outerHTML.slice(0, 9000);
    } catch (_) {
      return "";
    }
  }

  function expandAll() {
    document.querySelectorAll("article button, article span, article p").forEach((el) => {
      const t = (el.innerText || "").trim().toLowerCase();
      if (t === "selengkapnya" || t === "lihat selengkapnya") {
        try { el.click(); } catch (_) {}
      }
    });
  }

  async function scrapeVisible() {
    expandAll();
    await sleep(350);
    return findReviewCards().map(parseCard).filter((r) => r.review || r.rating);
  }

  const keyOf = (r) => [r.name, r.date, r.rating, r.review.slice(0, 80)].join("¦");
  const signature = () => findReviewCards().map((c) => c.innerText.slice(0, 40)).join("|");

  function findNextButton() {
    return (
      document.querySelector('button[aria-label^="Laman berikutnya"]') ||
      document.querySelector('button[aria-label*="berikutnya" i]') ||
      document.querySelector('button[aria-label*="next" i]')
    );
  }
  const isDisabled = (b) => !b || b.disabled || b.getAttribute("aria-disabled") === "true";

  async function waitForChange(prev, timeout = 7000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      await sleep(300);
      const sig = signature();
      if (sig && sig !== prev) return true;
    }
    return false;
  }

  async function waitForReviews(timeout = 20000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      if (findReviewCards().length) return true;
      window.scrollBy(0, Math.round(window.innerHeight * 0.8));
      await sleep(500);
    }
    return false;
  }

  function productMeta() {
    const og = (p) => {
      const el = document.querySelector(`meta[property="${p}"]`);
      return (el && el.content) || "";
    };
    const h1 = document.querySelector("h1");
    let title = og("og:title") || (h1 && h1.innerText) || document.title;
    title = title.replace(/^Ulasan\s+/i, "").replace(/\s*\|\s*Tokopedia.*$/i, "").trim();
    return { title, image: og("og:image") };
  }

  async function run({ maxPages = 10, delay = 1200 }) {
    running = true;
    stopRequested = false;
    try {
      const ok = await waitForReviews();
      if (!ok) {
        send({
          type: "error",
          message: "Ulasan tidak ditemukan di halaman ini. Pastikan produknya punya ulasan, dan Tokopedia tidak sedang meminta verifikasi.",
        });
        return;
      }
      const first = findReviewCards()[0];
      if (first) first.scrollIntoView({ block: "center" });
      send({ type: "meta", ...productMeta(), sample: first ? sampleHtml(first) : "" });

      const seen = new Set();
      let page = 1;
      while (page <= maxPages && !stopRequested) {
        const fresh = [];
        for (const r of await scrapeVisible()) {
          const k = keyOf(r);
          if (!seen.has(k)) { seen.add(k); fresh.push(r); }
        }
        send({ type: "batch", page, reviews: fresh });

        const next = findNextButton();
        if (isDisabled(next)) break;
        const sig = signature();
        next.scrollIntoView({ block: "center" });
        next.click();
        if (!(await waitForChange(sig))) break;
        await sleep(delay);
        page++;
      }
      send({ type: "done", stopped: stopRequested });
    } catch (e) {
      send({ type: "error", message: String((e && e.message) || e) });
    } finally {
      running = false;
    }
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg) return;
    if (msg.kind === "tkp-start") {
      if (running) { sendResponse({ ok: false }); return; }
      run(msg.options || {});
      sendResponse({ ok: true });
    } else if (msg.kind === "tkp-stop") {
      stopRequested = true;
      sendResponse({ ok: true });
    }
  });
})();
